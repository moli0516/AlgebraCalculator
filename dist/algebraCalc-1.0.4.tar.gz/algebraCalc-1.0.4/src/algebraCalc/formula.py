import math

def pyth(a: float, b: float) -> float:
    return math.sqrt(a**2 + b**2)